﻿namespace BigBang.Models.DTO
{
    public class DoctorDTO:Doctor
    {
        public string? PasswordClear { get; set; }
    }
}
