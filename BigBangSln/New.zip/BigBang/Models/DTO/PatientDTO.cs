﻿namespace BigBang.Models.DTO
{
    public class PatientDTO:Patient
    {
        public string? PasswordClear { get; set; }
    }
}

